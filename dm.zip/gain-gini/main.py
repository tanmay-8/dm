import pandas as pd
import math

def read_data(filename):
    df = pd.read_csv(filename)
    return df

def entropy(series):
    values = series.value_counts(normalize=True)
    ent = -sum(p * math.log2(p) for p in values if p > 0)
    print(f"Entropy of {series.name}: {ent:.4f}")
    return ent

def gini_index(series):
    values = series.value_counts(normalize=True)
    gini = 1 - sum(p ** 2 for p in values)
    print(f"Gini index of {series.name}: {gini:.4f}")
    return gini

def info_gain(df, attr, target):
    total_entropy = entropy(df[target])
    weighted_entropy = 0
    for val, subset in df.groupby(attr):
        weight = len(subset) / len(df)
        ent = entropy(subset[target])
        weighted_entropy += weight * ent
        print(f"  {attr}={val}: weight={weight:.3f}, entropy={ent:.4f}")
    gain = total_entropy - weighted_entropy
    print(f"Information Gain for {attr}: {gain:.4f}")
    return gain

def gini_split(df, attr, target):
    weighted_gini = 0
    for val, subset in df.groupby(attr):
        weight = len(subset) / len(df)
        gini = gini_index(subset[target])
        weighted_gini += weight * gini
        print(f"  {attr}={val}: weight={weight:.3f}, gini={gini:.4f}")
    print(f"Gini Split for {attr}: {weighted_gini:.4f}")
    return weighted_gini

def main():
    target = input("Enter target (class) column name: ")
    df = read_data('data.csv')
    results = []
    for col in df.columns:
        if col == target:
            continue
        print(f"\n--- Attribute: {col} ---")
        gain = info_gain(df, col, target)
        gini = gini_split(df, col, target)
        results.append({"attribute": col, "gain": gain, "gini": gini})
  
    out_df = pd.DataFrame(results)
    out_df.to_csv("gain_gini_output.csv", index=False)
    print("\nResults saved to gain_gini_output.csv")
    print(out_df)

if __name__ == "__main__":
    main()
