import pandas as pd
from collections import Counter

def read_data(filename):
	df = pd.read_csv(filename)
	return df

def get_priors(df, target):
	priors = df[target].str.lower().value_counts(normalize=True).to_dict()
	print("\nClass priors:")
	for cls, p in priors.items():
		print(f"  P({cls}) = {p:.4f}")
	return priors

def get_likelihoods(df, case, target):
	df = df.copy()
	for col in df.columns:
		df[col] = df[col].astype(str).str.lower()
	case_lower = {k: v.lower() if isinstance(v, str) else v for k, v in case.items()}
	likelihoods = {}
	for cls in df[target].unique():
		cls_lower = str(cls).lower()
		subset = df[df[target] == cls]
		likelihoods[cls_lower] = 1.0
		for col, val in case_lower.items():
			count = (subset[col] == val).sum()
			prob = count / len(subset) if len(subset) > 0 else 0
			likelihoods[cls_lower] *= prob
	return likelihoods

def get_posteriors(priors, likelihoods):
	posteriors = {}
	for cls in priors:
		post = priors[cls] * likelihoods[cls]
		posteriors[cls] = post
	return posteriors

def main():
	target = input("Enter target (class) column name: ")
	df = read_data('data.csv')
	feature_cols = [col for col in df.columns if col != target]
	print("\nEnter values for the case to classify:")
	case = {}
	for col in feature_cols:
		val = input(f"  {col}: ")
		case[col] = val
	priors = get_priors(df, target)
	likelihoods = get_likelihoods(df, case, target)
	posteriors = get_posteriors(priors, likelihoods)
	predicted = max(posteriors, key=posteriors.get)
	print(f"\nPredicted class: {predicted}")
	out_row = {**case, 'predicted_class': predicted}
	out_df = pd.DataFrame([out_row])
	out_df.to_csv('bayes_output.csv', index=False)
	print("\nResult saved to bayes_output.csv")

if __name__ == "__main__":
	main()
