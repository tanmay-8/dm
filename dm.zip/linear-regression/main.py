import pandas as pd

def read_data(filename):
    df = pd.read_csv(filename)
    return df

def linear_regression(x, y):
    n = len(x)
    mean_x = sum(x) / n
    mean_y = sum(y) / n
    print(f"Mean of X: {mean_x:.4f}")
    print(f"Mean of Y: {mean_y:.4f}")
    num = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))
    den = sum((xi - mean_x) ** 2 for xi in x)
    print(f"Numerator (Σ(xi - x̄)(yi - ȳ)): {num:.4f}")
    print(f"Denominator (Σ(xi - x̄)^2): {den:.4f}")
    slope = num / den if den != 0 else 0
    intercept = mean_y - slope * mean_x
    print(f"Slope (b1): {slope:.4f}")
    print(f"Intercept (b0): {intercept:.4f}")
    return slope, intercept

def main():
    df = read_data('data.csv')
    x_col = input("Enter independent variable (X) column name: ")
    y_col = input("Enter dependent variable (Y) column name: ")
    x = df[x_col].astype(float).tolist()
    y = df[y_col].astype(float).tolist()
    slope, intercept = linear_regression(x, y)
    print(f"\nRegression equation: {y_col} = {intercept:.4f} + {slope:.4f}*{x_col}")
    out_df = pd.DataFrame({
        x_col: x,
        y_col: y,
        'Predicted': [intercept + slope * xi for xi in x]
    })
    out_df.to_csv('linear_regression_output.csv', index=False)
    print("\nResults saved to linear_regression_output.csv")

if __name__ == "__main__":
    main()
