import pandas as pd
import matplotlib.pyplot as plt
import itertools

DATA_PATH = "data.csv"
OUT_PATH = "dbscan.csv"


def dist(a, b):
    return sum((x - y) ** 2 for x, y in zip(a, b))**0.5

def region_query(rows, point_idx, eps2):
    p = rows[point_idx]
    neighbors = []
    for j, q in enumerate(rows):
        if dist(p, q) <= eps2:
            neighbors.append(j)
    return neighbors


def dbscan(rows, eps, min_samples):
    n = len(rows)
    labels = [None] * n
    cluster_id = 0
    eps2 = eps * eps

    for i in range(n):
        if labels[i] is not None:
            continue

        neighbors = region_query(rows, i, eps2)
        if len(neighbors) < min_samples:
            labels[i] = -1
            continue

        labels[i] = cluster_id
        seeds = neighbors.copy()
        k = 0
        while k < len(seeds):
            j = seeds[k]
            if labels[j] is None:
                labels[j] = cluster_id
                j_neighbors = region_query(rows, j, eps2)
                if len(j_neighbors) >= min_samples:
                    for nb in j_neighbors:
                        if nb not in seeds:
                            seeds.append(nb)
            elif labels[j] == -1:
                labels[j] = cluster_id
            k += 1

        cluster_id += 1

    return labels


def main():
    df = pd.read_csv(DATA_PATH)
    num_cols = list(df.select_dtypes(include="number").columns)
    if not num_cols:
        raise SystemExit("No numeric columns found in the CSV.")

    df_num = df[num_cols].dropna()
    rows = df_num.values.tolist()
    indexes = df_num.index.tolist()

    try:
        eps = float(input("Enter neighborhood radius eps : ").strip())
    except Exception:
        eps = 0.5
    try:
        min_samples = int(input("Enter min_samples : ").strip())
    except Exception:
        min_samples = 5
    if eps <= 0:
        eps = 0.5
    if min_samples < 1:
        min_samples = 1

    labels = dbscan(rows, eps, min_samples)

    df_out = df.copy()
    df_out["cluster"] = pd.NA
    for idx, lbl in zip(indexes, labels):
        df_out.at[idx, "cluster"] = int(lbl)
    df_out.to_csv(OUT_PATH, index=False)

    n_noise = sum(1 for l in labels if l == -1)
    cluster_ids = sorted(set(l for l in labels if l is not None and l >= 0))
    counts = {cid: labels.count(cid) for cid in cluster_ids}

    print(f"\nDBSCAN results (eps={eps}, min_samples={min_samples}):")
    print("Clusters and sizes:")
    for cid in cluster_ids:
        print(f"  Cluster {cid}: {counts[cid]} points")
    print(f"  Noise: {n_noise} points")


if __name__ == "__main__":
    main()
