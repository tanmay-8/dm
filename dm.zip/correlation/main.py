import pandas as pd
import math

df = pd.read_csv('data.csv')

item_cols = [col for col in df.columns if col != 'TID']
pearson_results = []

for i in range(len(item_cols)):
    for j in range(i+1, len(item_cols)):
        col1 = item_cols[i]
        col2 = item_cols[j]
        x = df[col1].values
        y = df[col2].values
        n = len(x)
        x_mean = sum(x) / n
        y_mean = sum(y) / n
        numerator = sum((xi - x_mean) * (yi - y_mean) for xi, yi in zip(x, y))
        denominator = math.sqrt(
            sum((xi - x_mean) ** 2 for xi in x) * sum((yi - y_mean) ** 2 for yi in y)
        )
        r = numerator / denominator if denominator != 0 else float('nan')
        pearson_results.append({
            'Item 1': col1,
            'Item 2': col2,
            'Pearson Correlation': r
        })
        print(f"Pearson correlation between {col1} and {col2}: {r}")

pearson_df = pd.DataFrame(pearson_results)
pearson_df.to_csv('pearson_correlation_output.csv', index=False)
