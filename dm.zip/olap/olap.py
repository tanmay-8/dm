import csv


def load_data(filename):
    data = []
    with open(filename, "r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            row["Sales"] = int(row["Sales"])
            data.append(row)
    return data


def rollup(data, column):
    result = {}
    for row in data:
        key = row[column]
        if key not in result:
            result[key] = 0
        result[key] += row["Sales"]
    return result


def drilldown(data, col1, col2):
    result = {}
    for row in data:
        key = (row[col1], row[col2])
        if key not in result:
            result[key] = 0
        result[key] += row["Sales"]
    return result


def slice_data(data, column, value):
    result = []
    for row in data:
        if str(row[column]) == str(value):
            result.append(row)
    return result


def dice(data, conditions):
    result = []
    for row in data:
        match = True
        for col, val in conditions.items():
            if str(row[col]) != str(val):
                match = False
                break
        if match:
            result.append(row)
    return result


def print_table(data, headers):
    print("-" * 80)
    print(" | ".join(h.ljust(15) for h in headers))
    print("-" * 80)

    for row in data:
        print(" | ".join(str(row[h]).ljust(15) for h in headers))
    print("-" * 80)


if __name__ == "__main__":
    data = load_data("sales_data.csv")

    print("Choose OLAP Operation:")
    print("1. Roll-up")
    print("2. Drill-down")
    print("3. Slice")
    print("4. Dice")

    choice = int(input("Enter choice (1-4): "))

    if choice == 1:
        col = input("Enter column for Roll-up (Year/Quarter/Region/Product): ")
        result = rollup(data, col)
        rows = [{col: k, "Total Sales": v} for k, v in result.items()]
        print_table(rows, [col, "Total Sales"])

    elif choice == 2:
        col1 = input("Enter first column (Year/Region): ")
        col2 = input("Enter second column (Quarter/Product): ")
        result = drilldown(data, col1, col2)
        rows = [{col1: k[0], col2: k[1], "Total Sales": v}
                for k, v in result.items()]
        print_table(rows, [col1, col2, "Total Sales"])

    elif choice == 3:
        col = input("Enter column for Slice (Year/Quarter/Region/Product): ")
        val = input(f"Enter value for {col}: ")
        result = slice_data(data, col, val)
        if result:
            print_table(result, result[0].keys())
        else:
            print("No data found!")

    elif choice == 4:
        n = int(input("How many conditions? "))
        conditions = {}
        for i in range(n):
            col = input("Enter column name: ")
            val = input("Enter value: ")
            conditions[col] = val
        result = dice(data, conditions)
        if result:
            print_table(result, result[0].keys())
        else:
            print("No data found!")

    else:
        print("Invalid choice!")
